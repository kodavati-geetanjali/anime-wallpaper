import React, { useEffect, useState } from "react";
import axios from "axios";
 //import "../css/App.css"; 
 import Navbar from "../components/navbar"; // Link the CSS file here
 import Wallpaper from "../components/wallpaper"; // Import the Wallpaper component
import { Route } from "react-router-dom";
import { Routes } from "react-router-dom";

function App() {
  

  return (
    <>
      <Navbar />
      <main className="app-container">
        <Routes>
          {/* Add more routes as needed */}
          <Route path="/" element={<Wallpaper />} />
          <Route path="/anime" element={<Wallpaper />} />
        </Routes>
      </main >
    </>
  );
}



export default App;
