import { useState } from "react";

const Wallpaper = () => {
  const [wallpapers, setWallpapers] = useState([]);

  return (
    <div className="wallpaper-container">
      {wallpapers.map((wallpaper) => (
        <div key={wallpaper.id} className="wallpaper-item">
          <img src={wallpaper.imageUrl} alt={wallpaper.title} />
        </div>
      ))}
    </div>
  );
};

export default Wallpaper;
