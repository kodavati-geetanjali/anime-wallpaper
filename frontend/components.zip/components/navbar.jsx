import {Link} from 'react-router-dom';
//import '../css/Navbar.css';

const Navbar = () => {
  return (
    <nav className="navbar">
        <div className="navbar-brand">
          <Link to="/">AniWall</Link>
        </div>
        <div className="navbar-middle">
            <div className="navbar-links">
            <Link to="/anime " className='nav-link'>Saved</Link>
            </div>
            </div>
        <div className='navbar-search'>
          <input type="text" placeholder="Search..." className='search-input' />
            <button className='search-button'>Search</button>
        </div>
    </nav>
  );
};

export default Navbar;
